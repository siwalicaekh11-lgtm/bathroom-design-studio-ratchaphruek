# Bathroom Design Studio — Full Catalog รุ่นเริ่มต้น

## สถานะปัจจุบัน
- `index.html` เป็นเวอร์ชันเพิ่มตัวกรอง DCC/RCI / ขนาด / ผิวหน้า / สถานะภาพ และ Gallery หลายหน้าลาย โดยรักษา Export แบบเรียบหรูเดิม
- `catalog.json` เป็นเพียงชุดตั้งต้น 16 SKU ที่มีแหล่งอ้างอิงหรือข้อมูลเริ่มต้น **ยังไม่มีรูปดาวน์โหลดที่ยืนยันในชุดนี้** บาง SKU มีลิงก์ภาพภายนอกที่อาจไม่แสดงหรือ Export ไม่ได้
- `scripts/sync_catalog.py` เป็นโปรแกรมดึงจากหน้าสินค้าสาธารณะของบริษัท, ตีกรอบ SKU, ดาวน์โหลดภาพที่พบจริงเข้าที่ `assets/catalog/SKU` และสร้างรายงานขาดภาพ
- `.github/workflows/catalog-sync.yml` รันสคริปต์จาก GitHub Actions แล้ว Commit `catalog.json`, `catalog_audit.csv`, `assets/catalog` เข้า GitHub

**ห้ามรายงานว่า Full Catalog หรือภาพครบ 100% จนกว่างานซิงก์จะรันสำเร็จและตรวจเทียบรายการกับแหล่งข้อมูลบริษัท**

## วิธีเผยแพร่ครั้งแรก — Repository เดิม
Repository: https://github.com/siwalicaekh11-lgtm/bathroom-design-studio-ratchaphruek

1. อัปเดต `index.html` เดิมใน branch `main` โดยแทนด้วยไฟล์ `index.html` ในโฟลเดอร์ชุดนี้ (ไฟล์เดิมมี `index_luxury_presentation.html` สำหรับสำรอง)
2. เพิ่ม `catalog.json`, `catalog_audit.csv` ที่ root ของ Repository
3. เพิ่ม `scripts/sync_catalog.py` และ `.github/workflows/catalog-sync.yml` โดยรักษาโครงสร้างไดเรกทอรีตามนี้ (แนะนำ GitHub Desktop หรือ git บนคอมพิวเตอร์ ถ้าทำจาก iPhone จะยากขึ้น)
4. เปิด GitHub → Settings → Actions → General → Workflow permissions → ให้ `Read and write permissions` สำหรับ GitHub Actions (หากอนุญาตในบัญชี)
5. เปิดแท็บ Actions → `Sync verified DCC and RCI tile catalog` → `Run workflow` โดยครั้งแรกอาจใช้เวลานานเนื่องจากดาวน์โหลดข้อมูลและภาพจริงจำนวนมาก
6. ตรวจ workflow ว่าสำเร็จและเปิด `catalog_audit.csv` เพื่อตรวจจำนวนรูปที่พบ/รูปที่ขาด จากนั้นตรวจ Render Deploy — หากระบบไม่ได้ Deploy อัตโนมัติ ให้ Trigger Deploy จาก Commit ล่าสุด
7. เปิด https://bathroom-design-studio-ratchaphruek.onrender.com/ (หรือเวอร์ชันในไฟล์ใหม่ที่แยกไว้) แล้วกดหน้าออกแบบ

## ความแม่นยำ
- `Random 8` ในคำอธิบายหมายถึง **จำนวนหน้าลายที่ผู้ผลิตระบุ** ไม่ได้แปลว่าระบบดาวน์โหลดรูป 8 ภาพได้
- `verified_images` ใน audit คือจำนวน **ไฟล์ภาพที่ดาวน์โหลดและตรวจรูปแบบได้จริงจากหน้าผลิตภัณฑ์**; ยังต้องตรวจด้วยสายตาว่าตรงสินค้าครบทุกภาพ
- ระบบจะไม่ปลอมรูป แทนภาพ หรือคาดเดาหน้าลายที่ยังไม่ได้รับไฟล์จริง
- หากรูปไม่ครบ จำเป็นต้องรับไฟล์หน้าลายต้นฉบับจากโรงงานหรือฝ่ายผลิตภัณฑ์ แล้วเพิ่มในฐานข้อมูล
- บางเว็บไซต์บล็อกการเก็บภาพหรือเปลี่ยน HTML ได้ ต้องตรวจ log ของ workflow และปรับ parser ตามโครงสร้างล่าสุด
- การดึงข้อมูลจำนวนมากควรตรวจสิทธิ์และเงื่อนไขการนำข้อมูลสินค้าขององค์กรกลับมาเผยแพร่บนเว็บไซต์นี้

## ข้อจำกัดที่ยังต้องพัฒนา
- Version นี้เป็นโครงพื้นฐานต่อยอด ไม่ใช่ฐานข้อมูลครบทั้งสองแบรนด์
- ระบบฝากรูปไว้กับ GitHub/Render เหมาะกับการทดลองและใช้งานขนาดจำกัด ถ้าเก็บภาพทุกหน้าเป็นจำนวนมากควรย้ายไป Object Storage/CDN ที่องค์กรอนุมัติ เพื่อลดขนาด Git Repository
- ต้องตรวจตำแหน่งกระเบื้อง Floor/Wall, SKU ที่ซ้ำ, ผิวหน้า และรูปแต่ละเฟซก่อนยืนยันเป็นแคตตาล็อกหลัก
- Runtime บน GitHub Actions อาจเกินเวลาหรือชนอัตราจำกัดของเว็บไซต์ต้นทาง; ระบบจะแจ้งข้อผิดพลาดผ่าน Logs และไม่สร้างรูปแทน

## ผลการทดสอบก่อนส่ง
- `node --check` ผ่านสำหรับ JavaScript ของเว็บไซต์
- Browser automation ตรวจว่า Studio เปิด, ตัวกรองแสดง, โหลด catalog.json ทดสอบ, Gallery หลายเฟซเปิดได้, ปุ่ม Export แบบเรียบหรูยังอยู่, ไม่พบ JavaScript error
- Python script ผ่าน compile และ unit test ตัวอ่านข้อมูลสินค้า/แหล่งรูป
- **ยังไม่ได้รัน crawler กับเว็บไซต์ต้นทางจริง** เนื่องจากสภาพแวดล้อมจัดทำไฟล์ไม่อนุญาตเข้าถึงเครือข่ายภายนอกผ่าน Python
