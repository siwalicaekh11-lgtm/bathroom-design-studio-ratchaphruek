#!/usr/bin/env python3
"""DCC / RCI catalogue importer. Source-first, photos verified, no synthetic variants.
Usage: python scripts/sync_catalog.py --max-products 2500 --max-faces 16
Requires public HTTP access. The ChatGPT sandbox is network-disabled: run via GitHub Actions.

Rules:
- Only approved DCC/RCI source domains as product records.
- Each downloaded image must be a real image; store exact decoded pixels resampled for presentation.
- "Random 8" means expected face count, not evidence that 8 photos were found.
- Never label a missing face as photographed.
"""
import argparse, concurrent.futures, datetime, hashlib, io, json, os, re, sys, time
from pathlib import Path
from urllib.parse import urljoin, urlparse, urldefrag
import requests
from bs4 import BeautifulSoup
from PIL import Image, ImageOps, UnidentifiedImageError

BASES = ["https://www.dcctoyou.com", "https://www.rcitiles.com"]
HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; DCCProjectDesign/1.0; project catalog attribution; public HTML only)", "Accept-Language": "th-TH,th;q=0.9,en-US;q=0.7,en;q=0.6"}
SKU_RE = re.compile(r"\b[A-Z]{2,5}[A-Z0-9]{3,10}\b")
DIM_RE = re.compile(r"(\d{2,3})\s*[x×X]\s*(\d{2,3})\s*(?:cm|ซ\.?ม\.?|เซนติเมตร)?", re.I)
FACE_RE = re.compile(r"(?:Random|แรนดอม|หน้าลาย)\s*[:\-]?\s*(\d{1,2})", re.I)
ALLOWED_IMAGE_HOSTS = {"image.makewebeasy.net", "image.makewebeasy.com", "cloud.makewebstatic.com", "www.rcitiles.com", "rcitiles.com", "www.dcctoyou.com", "dcctoyou.com"}
OUTPUT = Path(__file__).resolve().parent.parent
SEEN = set()
SESSION = requests.Session(); SESSION.headers.update(HEADERS)


def get(url, timeout=18, attempts=2):
    for attempt in range(attempts):
        try:
            r=SESSION.get(url, timeout=timeout, allow_redirects=True)
            if r.status_code in (403, 404, 410, 429):
                print('skip HTTP', r.status_code, url[:90]); return None
            r.raise_for_status()
            return r
        except requests.RequestException as exc:
            print('request error', url[:70], str(exc)[:120], file=sys.stderr)
            time.sleep(.5 + attempt*.9)
    return None


def norm_link(href, base):
    if not href: return None
    href = urljoin(base, href)
    href = urldefrag(href)[0]
    p=urlparse(href)
    if p.scheme != 'https': return None
    if p.netloc.lower() not in {"www.dcctoyou.com", "dcctoyou.com", "www.rcitiles.com", "rcitiles.com"}: return None
    return href


def listing_links(soup, base):
    links=set()
    for a in soup.select('a[href]'):
        u=norm_link(a.get('href'), base)
        if u and re.search(r'/product/\d+[-/]\d+/', urlparse(u).path):links.add(u)
    return links


def crawl_listing(start, depth, max_pages):
    """Discover via pagination + category links. Hard cap; no infinite crawl."""
    q=[start]; visited=set(); products=set()
    while q and len(visited)<max_pages:
        u=q.pop(0)
        if u in visited:continue
        visited.add(u)
        resp=get(u)
        if resp is None:continue
        soup=BeautifulSoup(resp.text,'html.parser')
        found=listing_links(soup,resp.url);products.update(found)
        print('listing',len(visited),'found',len(found),'total',len(products),u[:80],flush=True)
        # Only follow listing pages explicitly linked by pagination or same prefix with page parameter.
        for a in soup.select('a[href]'):
            v=norm_link(a.get('href'),resp.url)
            if not v or v in visited or v in q:continue
            if '/category' not in urlparse(v).path and '/productbrand/' not in urlparse(v).path:continue
            if v==u:continue
            cls=' '.join(a.get('class',[])).lower()
            rel=' '.join(a.get('rel',[])).lower()
            txt=a.get_text(' ',strip=True).lower()
            parent_cls=' '.join(a.parent.get('class',[])).lower() if a.parent else ''
            is_page=('page=' in v or 'pagination' in cls+parent_cls or 'next' in cls+rel or txt in ('next','ถัดไป','ต่อไป','›','»') or (txt.isdigit() and len(txt)<3))
            if is_page:q.append(v)
        # Probe common MakeWebEasy pagination query patterns once per site.
        if len(visited)==1 and len(found)>=10:
            for n in range(2,depth+1):
                for key in ('page','p'):
                    v=start+('?' if '?' not in start else '&')+key+'='+str(n)
                    if v not in visited and v not in q:q.append(v)
        time.sleep(.16)
    return products


def xml_sitemap_links(base, max_xml=22):
    """Try sitemap, but fall back to listing if unavailable."""
    urls=set(); q=[base+'/sitemap.xml',base+'/sitemap_index.xml']; seen=set()
    while q and len(seen)<max_xml:
        u=q.pop(0)
        if u in seen:continue
        seen.add(u)
        r=get(u,timeout=15,attempts=1)
        if not r or '<loc>' not in r.text[:2000000]:continue
        links=re.findall(r'<(?:[\w]+:)?loc>\s*([^<]+)\s*</(?:[\w]+:)?loc>',r.text)
        for x in links:
            x=x.replace('&amp;','&')
            good=norm_link(x,base)
            if not good:continue
            path=urlparse(good).path
            if re.search(r'/product/\d+[-/]\d+/',path):urls.add(good)
            elif 'sitemap' in path and good not in seen:q.append(good)
    print('sitemap',base,len(urls))
    return urls


def _jsonld_images(soup):
    arr=[]
    def walk(value):
        if isinstance(value,list):
            for z in value:walk(z)
        elif isinstance(value,dict):
            t=value.get('@type',[])
            if isinstance(t,str):t=[t]
            if any('product' in str(x).lower() for x in t):
                raw=value.get('image',[])
                if isinstance(raw,str):raw=[raw]
                for v in raw:
                    if isinstance(v,str):arr.append(v)
                    elif isinstance(v,dict) and isinstance(v.get('url'),str):arr.append(v['url'])
            if '@graph' in value:walk(value['@graph'])
    for el in soup.select('script[type="application/ld+json"]'):
        try:walk(json.loads(el.string or el.get_text()))
        except (ValueError,TypeError):continue
    return arr


def photo_candidates(soup, base):
    """Take explicitly product-linked imagery; no site banner or unrelated gallery."""
    found=[]
    for img in _jsonld_images(soup): found.append(img)
    for tag in soup.select('meta[property="og:image"],meta[name="twitter:image"]'):
        if tag.get('content'):found.append(tag['content'])
    selectors=(
        '[class*="product-gallery"] img', '[class*="productGallery"] img',
        '[class*="product-image"] img', '[class*="productImage"] img',
        '[class*="product-thumbnail"] img', '[class*="productThumbnail"] img',
        '[class*="product-detail-image"] img', '[class*="productDetailImage"] img',
        '[class*="product-slider"] img', '[class*="productSlider"] img',
        '[data-fancybox*="product"] img',
        '[class*="product-gallery"] a[href]'
    )
    for sel in selectors:
        for tag in soup.select(sel):
            for attr in ('data-zoom-image','data-large-image','data-full','data-src','data-original','src','href','srcset'):
                src=tag.get(attr)
                if not src:continue
                if attr=='srcset':src=src.split(',')[-1].strip().split(' ')[0]
                found.append(src)
    out=[]; seen=set()
    for src in found:
        src=urljoin(base,src.strip())
        host=urlparse(src).netloc.lower()
        if not src.startswith('https://') or host not in ALLOWED_IMAGE_HOSTS:continue
        if re.search(r'(logo|icon|banner|payment|footer|avatar|flags|social|facebook|line_logo)',src,re.I):continue
        canonical=src.split('?')[0].replace('r_400x400','r_1200x1200').replace('r_600x600','r_1200x1200')
        if canonical not in seen:
            out.append(src);seen.add(canonical)
    return out[:32]


def finish_from(text):
    text=text.lower()
    for rg,label in [
        (r's[- ]?as|soft\s*anti[- ]?slip|ซอฟท์\s*กันลื่น','S-AS'),
        (r'\b(?:as)\b|anti[- ]?slip|ผิวกันลื่น','AS'),
        (r'\b(?:st)\b|soft\s*touch|ซอฟท์\s*ทัช','ST'),
        (r'\b(?:sm)\b|soft\s*matt|ซอฟท์\s*แมท','SM'),
        (r'polished|พอลิช|ผิวมัน','Polished'),
        (r'satin|ซาติน','Satin'),
        (r'gloss|ผิวเงา','Gloss'),
        (r'matt|matte|แมท|ด้าน','Matt'),
        (r'ผิวหยาบ','Rough')]:
        if re.search(rg,text,re.I):return label
    return 'ไม่ระบุ'


def product_parse(url):
    r=get(url)
    if not r:return None
    soup=BeautifulSoup(r.text,'html.parser')
    h=soup.select_one('h1')
    title=h.get_text(' ',strip=True) if h else ''
    main=soup.select_one('main') or soup
    detail=main.get_text(' ',strip=True)
    sku_match=re.search(r'\bSKU\s*:\s*([A-Z0-9]{6,14})\b',detail,re.I)
    if not sku_match:sku_match=re.search(r'\bSKU\s*:\s*([A-Z0-9]{6,14})\b',soup.get_text(' ',strip=True),re.I)
    if not sku_match:return None
    sku=sku_match.group(1).upper()
    dm=DIM_RE.search(detail)
    if not dm:return None
    w,h=int(dm.group(1)),int(dm.group(2))
    if not (10<=w<=120 and 10<=h<=180):return None
    if not re.search(r'กระเบื้อง|tile|porcelain|granito|ceramic', title+' '+detail[:380],re.I):return None
    nm=title.strip()
    # site determines presentation grouping, not manufacturer ownership
    site='DCC' if 'dcctoyou.com' in url else 'RCI'
    info=detail[:2500]
    kind='wall' if re.search(r'บุผนัง|กระเบื้องผนัง|wall tile|wall tiles',info,re.I) else 'floor'
    faces=FACE_RE.search(info)
    return {'sku':sku,'name':nm[:160], 'nameEn':'', 'width':w,'height':h,'finish':finish_from(nm+' '+info),'kind':kind,'site':site,'url':url,
            'expectedFaces':int(faces.group(1)) if faces else None,'candidateImages':photo_candidates(soup,r.url)}


def store_photo(url,sku, limit=1500000):
    # Do not fetch unknown external hosts or arbitrary URLs
    host=urlparse(url).netloc.lower()
    if host not in ALLOWED_IMAGE_HOSTS:return None
    r=get(url,timeout=14,attempts=1)
    if not r:return None
    if len(r.content)>14*1024*1024:return None
    try:
        im=Image.open(io.BytesIO(r.content))
        im.load()
        if im.width<180 or im.height<180:return None
        im=ImageOps.exif_transpose(im).convert('RGB')
        im.thumbnail((1100,1100),Image.Resampling.LANCZOS)
        output=io.BytesIO()
        im.save(output,'JPEG',quality=82,optimize=True)
        data=output.getvalue()
        if len(data)>limit:return None
        h=hashlib.sha256(data).hexdigest()[:16]
        directory=OUTPUT/'assets'/'catalog'/sku
        directory.mkdir(parents=True,exist_ok=True)
        target=directory/(h+'.jpg')
        if not target.exists():target.write_bytes(data)
        return {'path':target.relative_to(OUTPUT).as_posix(),'hash':h,'size':len(data),'resolution':[im.width,im.height]}
    except (UnidentifiedImageError,OSError,ValueError):return None


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--max-products',type=int,default=2500)
    ap.add_argument('--max-pages',type=int,default=160)
    ap.add_argument('--max-faces',type=int,default=16)
    ap.add_argument('--wait',type=float,default=.12)
    ap.add_argument('--no-images',action='store_true')
    args=ap.parse_args()
    old={}
    path=OUTPUT/'catalog.json'
    if path.exists():
        try:
            data=json.loads(path.read_text('utf-8'))
            old={p['sku']:p for p in data.get('products',[]) if 'sku' in p}
        except Exception as e:print('existing catalog read error',e)
    urls=set()
    for base in BASES:
        urls.update(xml_sitemap_links(base))
        urls.update(crawl_listing(base+'/category',18,args.max_pages))
    print('discovered unique product URLs',len(urls),flush=True)
    # Prefer DCC for duplicates as it includes main catalog; RCI for other unique SKUs
    ordered=sorted(urls,key=lambda u:('rcitiles.com' in u,u))[:args.max_products]
    products={}
    attempts=0
    for url in ordered:
        attempts+=1
        info=product_parse(url)
        if not info:continue
        sku=info['sku']
        if sku in products:continue
        previous=old.get(sku,{})
        urls_to_check=info.pop('candidateImages',[])
        faces=[]
        # Preserve previously verified local files
        for face in previous.get('faces',[]):
            if isinstance(face,str) and face.startswith('assets/catalog/') and (OUTPUT/face).is_file():faces.append(face)
        if not args.no_images:
            used=set()
            for candidate in urls_to_check:
                if len(faces)>=args.max_faces:break
                result=store_photo(candidate,sku)
                if not result:continue
                u=result['path']
                if u not in faces and result['hash'] not in used:faces.append(u);used.add(result['hash'])
                time.sleep(args.wait)
        product={k:v for k,v in info.items() if k!='candidateImages'}
        product['faces']=faces
        product['img']=faces[0] if faces else ''
        product['verifiedImageCount']=len(faces)
        product['imageStatus']='verified' if faces else 'missing'
        product['source']='official-public-catalog'
        product['checkedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        products[sku]=product
        if len(products)%30==0:print('processed',len(products),'images',sum(len(x['faces']) for x in products.values()),flush=True)
        time.sleep(args.wait)
    # Keep existing previously verified items when website is offline, do NOT label unverified URLs as verified.
    for sku,p in old.items():
        if sku in products:continue
        valid=[x for x in p.get('faces',[]) if isinstance(x,str) and x.startswith('assets/catalog/') and (OUTPUT/x).is_file()]
        if valid:
            p['faces']=valid;p['img']=valid[0];p['verifiedImageCount']=len(valid);p['imageStatus']='verified';products[sku]=p
    results=sorted(products.values(),key=lambda x:(x['site'],x['sku']))
    data={'version':3,'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':BASES,'totalRecords':len(results),
          'recordsWithVerifiedImages':sum(bool(x.get('faces')) for x in results),'totalVerifiedImages':sum(len(x.get('faces',[])) for x in results),
          'completenessNote':'Image count reflects verified downloaded images only. Random N is expected face count, not proof of N images. Unavailable images remain missing.',
          'products':results}
    if not results:
        print('ERROR: no verified products found; preserving existing catalog rather than replacing',file=sys.stderr);return 2
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    import csv
    with (OUTPUT/'catalog_audit.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(['sku','name','size_cm','finish','source','expected_random_faces','verified_images','missing_faces_estimate','image_status','product_url'])
        for product in results:
            expected=product.get('expectedFaces')
            verified=product.get('verifiedImageCount',0)
            writer.writerow([product['sku'],product['name'],f"{product['width']}x{product['height']}",product['finish'],product['site'],expected or '',verified,max((expected or 1)-verified,0),product['imageStatus'],product['url']])
    print('FINAL',json.dumps({k:data[k] for k in ('totalRecords','recordsWithVerifiedImages','totalVerifiedImages')},ensure_ascii=False));return 0

if __name__=='__main__':sys.exit(main())
