RCI BATHROOM DESIGN STUDIO — iPhone-ready website version

ปัญหาที่แก้: ไฟล์ Quick_Start.html เปิดใน Quick Look/หน้าพรีวิว iPhone ซึ่งไม่รองรับ JavaScript เหมือน Safari และหน้าเว็บเดิมต้องฝัง iframe/srcdoc

ไฟล์ index.html ใหม่เปิดโปรแกรมออกแบบโดยตรง ไม่มีการฝังหน้า Studio ใน iframe อีกต่อไป และทำงานกับโฟลเดอร์ assets/catalog เพื่อแสดงภาพกระเบื้องจริงจาก PDF

ติดตั้งออนไลน์: อัปโหลดไฟล์ ZIP นี้แทนไฟล์ Bathroom_Design_Studio_Full_Catalog_Starter.zip ใน GitHub repository bathroom-design-studio-ratchaphruek แล้ว Render service bathroom-studio-ratchaphruek-2026 กด Manual Deploy

ข้อควรทราบ: 161 SKU, ภาพที่แยกจากแคตตาล็อก 1,104 ภาพ ไม่ได้หมายความว่าครบสินค้าหรือ Random Faces ทุกปีของ DCC/RCI และเป็นเพียงภาพอ้างอิงเพื่อตรวจแบบ
